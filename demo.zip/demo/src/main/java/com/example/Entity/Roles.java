package com.example.Entity;

import javax.persistence.*;

@Entity
@Table(name = "com.example.Entity.Roles")
public class Roles {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column (name = "RolesId")
    private  long RolesId;

    @Column (name = "RolesName")
    private String RolesName;

    public long getRolesId() {
        return RolesId;
    }

    public void setRolesId(long rolesId) {
        RolesId = rolesId;
    }

    public String getRolesName() {
        return RolesName;
    }

    public void setRolesName(String rolesName) {
        RolesName = rolesName;
    }
}
