package com.example.Entity;

import javax.persistence.*;

@Entity
@Table(name = "com.example.Entity.Ticket")
public class Ticket {
    @Id @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "TicketId")
    private long TicketId;

    @Column (name = "EventId")
    private long EventId;

    @Column (name = "UserId")
    private long UserId;

    public long getTicketId() {
        return TicketId;
    }

    public void setTicketId(long ticketId) {
        TicketId = ticketId;
    }

    public long getEventId() {
        return EventId;
    }

    public void setEventId(long eventId) {
        EventId = eventId;
    }

    public long getUserId() {
        return UserId;
    }

    public void setUserId(long userId) {
        UserId = userId;
    }
}
