package com.example.Entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "com.example.Entity.Event")
public class Event {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column (name = "EventId")
    private long EventId;

    @Column (name = "EventName")
    private String EventName;

    @Column(name = "EventDate")
    private Date EventDate;

    @Column (name = "EventCapacity")
    private long EventCapacity;

    public long getEventId() {
        return EventId;
    }

    public void setEventId(long eventId) {
        EventId = eventId;
    }

    public String getEventName() {
        return EventName;
    }

    public void setEventName(String eventName) {
        EventName = eventName;
    }

    public Date getEventDate() {
        return EventDate;
    }

    public void setEventDate(Date eventDate) {
        EventDate = eventDate;
    }

    public long getEventCapacity() {
        return EventCapacity;
    }

    public void setEventCapacity(long eventCapacity) {
        EventCapacity = eventCapacity;
    }
}
