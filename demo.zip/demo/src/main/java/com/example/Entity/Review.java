package com.example.Entity;

import javax.persistence.*;

@Entity
public class Review {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column (name = "ReviewId")
    private long ReviewId;


    public long getReviewId() {
        return ReviewId;
    }

    public void setReviewId(long reviewId) {
        ReviewId = reviewId;
    }
}
