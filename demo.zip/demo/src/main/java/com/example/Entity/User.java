package com.example.Entity;

import javax.persistence.*;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;

@Entity
@Table(name = "com.example.Entity.User")

public class User {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long UserId;

    @Column(name = "NAME")
    private String UserName;

    @Column(name = "Password")
    private String Password;

    @Column(name = "Email")
    private String Email;
    @ManyToOne
    private Collection<Roles> roles= new ArrayList<>();
    @Column (name = "RolesId")
    private long RolesId;

    public long getUserId() {
        return UserId;
    }

    public void setUserId(long userId) {
        UserId = userId;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }
    public long getRolesId() {
        return RolesId;
    }

    public void setRolesId(long rolesId) {
        RolesId = rolesId;
    }
}

