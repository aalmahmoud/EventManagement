package com.example.Service;

import Repository.UserRepository;
import org.springframework.stereotype.Service;

@Service

public class UserService {
    private UserRepository userRepository;

}
