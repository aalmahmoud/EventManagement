CREATE TABLE Roles (
RolesId long NOT NULL PRIMARY KEY,
RolesName varchar(5) NOT NULL

);

CREATE TABLE Users(
UserId long NOT NULL PRIMARY KEY,
UserPassword varchar(10) NOT NULL,
UserName varchar(25) NOT NULL,
UserEmail varchar(40),
RolesId long(10) FOREIGN KEY REFERENCES Roles(RolesId)
);

--is deleted ?
--auditing


CREATE TABLE Events (
    EventID long NOT NULL PRIMARY KEY,
    EventName varchar(50) NOT NULL,
    EventDate date NOT NULL,
    EventCapacity varchar(50) NOT NULL,
    UserId long FOREIGN KEY REFERENCES Users(UserId)
    );

CREATE TABLE Tickets (
TicketId long NOT NULL PRIMARY KEY,
EventID long FOREIGN KEY REFERENCES Events(EventID),
UserId long FOREIGN KEY REFERENCES Users(UserId)
)

CREATE TABLE Reviews (
ReviewId long NOT NULL PRIMARY KEY

);