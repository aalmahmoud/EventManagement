--INSERT INTO Roles ( rolesid, name)
--VALUES (1,'Admin'),(0,'User');

--UPDATE Users
--SET firstname = 'Abdullah', lastname= 'Alharbi'
--WHERE userid = 1223344551;

--INSERT INTO Users ( userid, firstname, lastname,email)
--VALUES (1223344551,'Muhannad','Alomaran','example@example.com');

--DELETE from Users
--WHERE firstname='Muhannad';